#!/usr/bin/perl
my @attributes = ("MANF", "MANF#", "DIGIKEY#", "MOUSER#");
my %id = (
    "C_" => {
       "0402" => {
            "1.0pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H1R0BA01D", "DIGIKEY#" => "490-6206-1-ND", "MOUSER#" => "81-GRM1555C1H1R0BA1D"},
            "1.5pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H1R5BA01D", "DIGIKEY#" => "490-6212-1-ND", "MOUSER#" => "81-GRM1555C1H1R5BA1D"},
            "1.8pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H1R8BA01D", "DIGIKEY#" => "490-6215-1-ND", "MOUSER#" => "81-GRM1555C1H1R8BA1D"},
            "2pF"    => {MANF => "Murata", "MANF#" => "GRM1555C1H2R0BA01D", "DIGIKEY#" => "490-6226-1-ND", "MOUSER#" => "81-GRM1555C1H2R0BA1D"},
            "4.7pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H4R7BA01D", "DIGIKEY#" => "490-6244-1-ND", "MOUSER#" => "81-GRM1555C1H4R7BA1D"},
            "9pF"    => {MANF => "Murata", "MANF#" => "GRM1555C1H9R0BA01D", "DIGIKEY#" => "490-6257-1-ND", "MOUSER#" => "81-GRM1555C1H9R0BA1D"},
            "10pF"   => {MANF => "Murata", "MANF#" => "GRM1555C1H100FA01D", "DIGIKEY#" => "490-6186-1-ND", "MOUSER#" => "81-GRM1555C1H100FA1D"},
            "15pF"   => {MANF => "Murata", "MANF#" => "GRM1555C1H150FA01D", "DIGIKEY#" => "490-6200-1-ND", "MOUSER#" => "81-GRM1555C1H150FA1D"},
            "22pF"   => {MANF => "Murata", "MANF#" => "GRM1555C1E220GA01D", "DIGIKEY#" => "490-8173-1-ND", "MOUSER#" => "81-GRM1555C1E220GA1D"},
            "27pF"   => {MANF => "Murata", "MANF#" => "GRM1555C1H270GA01D", "DIGIKEY#" => "490-6224-1-ND", "MOUSER#" => "81-GRM1555C1H270GA1D"},
            "33pF"   => {MANF => "Murata", "MANF#" => "GRM1555C1H330GA01D", "DIGIKEY#" => "490-6232-1-ND", "MOUSER#" => "81-GRM1555C1H330GA1D"},
            "47pF"   => {MANF => "Murata", "MANF#" => "GRM1555C1H470GA01D", "DIGIKEY#" => "490-8206-1-ND", "MOUSER#" => "81-GRM1555C1H470GA1D"},
            "100pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H101GA01D", "DIGIKEY#" => "490-6188-1-ND", "MOUSER#" => "81-GRM1555C1H101GA1D"},
            "120pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H121GA01D", "DIGIKEY#" => "490-8183-1-ND", "MOUSER#" => "81-GRM1555C1H121GA1D"},
            "220pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H221JA01D", "DIGIKEY#" => "490-1293-1-ND", "MOUSER#" => "81-GRM1555C1H221JA1D"},
            "680pF"  => {MANF => "Murata", "MANF#" => "GRM1555C1H681JA01D", "DIGIKEY#" => "490-3240-1-ND", "MOUSER#" => "81-GRM1555C1H681JA1D"},
            "1nF"    => {MANF => "Murata", "MANF#" => "GRM1555C1H102JA01D", "DIGIKEY#" => "490-3244-1-ND", "MOUSER#" => "81-GRM1555C1H102JA1D"},
            "1.5nF"  => {MANF => "Murata", "MANF#" => "GRM155R71H152KA01J", "DIGIKEY#" => "490-6354-1-ND", "MOUSER#" => "81-GRM155R71H152KA1J"},
            "2.2nF"  => {MANF => "Murata", "MANF#" => "GRM155R71H222JA01D", "DIGIKEY#" => "490-6358-1-ND", "MOUSER#" => "81-GRM155R71H222JA1D"},
            "10nF"   => {MANF => "Murata", "MANF#" => "GRM155R71C103KA01D", "DIGIKEY#" => "490-1313-1-ND", "MOUSER#" => "81-GRM155R71C103KA1D"},
            "33nF"   => {MANF => "Murata", "MANF#" => "GRM155R71C333KA01J", "DIGIKEY#" => "490-6333-1-ND", "MOUSER#" => "81-GRM155R71C333KA1J"},
            "47nF"   => {MANF => "Murata", "MANF#" => "GRM155R71C473KA01J", "DIGIKEY#" => "490-6473-1-ND", "MOUSER#" => "81-GRM155R71C473KA1J"},
            "0.1uF"  => {MANF => "Murata", "MANF#" => "GRM155R61A104KA01D", "DIGIKEY#" => "490-1318-1-ND", "MOUSER#" => "81-GRM155R61A104KA1D"},
            "0.47uF" => {MANF => "Murata", "MANF#" => "GRM155R60J474KE19D", "DIGIKEY#" => "490-3266-1-ND", "MOUSER#" => "81-GRM155R60J474KE9D"},
            "1uF"    => {MANF => "Kemet",  "MANF#" => "C0402C105M8PACTU",   "DIGIKEY#" => "399-7766-1-ND", "MOUSER#" => "80-C0402C105M8P"},
            "2.2uF"  => {MANF => "Kemet",  "MANF#" => "C0402C225M8PACTU",   "DIGIKEY#" => "399-7375-1-ND", "MOUSER#" => "80-C0402C225M8P"},
        },
        "0805" => {
            "1uF"    => {MANF => "Murata", "MANF#" => "GRM21BR71A105KA01L", "DIGIKEY#" => "490-1695-1-ND", "MOUSER#" => "81-GRM40X105K10L"},
            "10uF"   => {MANF => "Murata", "MANF#" => "GRM21BR61A106KE19L", "DIGIKEY#" => "490-1709-1-ND", "MOUSER#" => "81-GRM21BR61A106KE19 "},
        },
    },
    "R_" => {
        "0402" => {
            "200"    => {MANF => "Panasonic", "MANF#" => "ERJ-2GEJ201X",  "DIGIKEY#" => "P200JCT-ND",  "MOUSER#" => "667-ERJ-2GEJ201X"},
            "10k"    => {MANF => "Panasonic", "MANF#" => "ERJ-2GEJ103X",  "DIGIKEY#" => "P10KJCT-ND",  "MOUSER#" => "667-ERJ-2GEJ103X"},
            "22k"    => {MANF => "Panasonic", "MANF#" => "ERJ-2GEJ223X",  "DIGIKEY#" => "P22KJCT-ND",  "MOUSER#" => "667-ERJ-2GEJ223X"},
            "56.2k"  => {MANF => "Panasonic", "MANF#" => "ERJ-2RKF5622X", "DIGIKEY#" => "P56.2KLCT-ND", "MOUSER#" => "667-ERJ-2RKF5622X"},
            "1M"     => {MANF => "Panasonic", "MANF#" => "ERJ-2GEJ105X",  "DIGIKEY#" => "P1.0MJCT-ND",  "MOUSER#" => "667-ERJ-2GEJ105X "},
        },
        "0805" => {
            "10k"    => {MANF => "Panasonic", "MANF#" => "ERJ-6GEYJ103V", "DIGIKEY#" => "P10KACT-ND",  "MOUSER#" => "667-ERJ-6GEYJ103V"},
        },
    },
    "L_" => {
        "0402" => {
            "1.2nH"    => {MANF => "Panasonic", "MANF#" => "ELJ-RF1N2ZFB", "DIGIKEY#" => "PCD1899CT-ND",  "MOUSER#" => "667-ELJ-RF1N2ZFB"},
            "1.5nH"    => {MANF => "Panasonic", "MANF#" => "ELJ-RF1N5ZFB", "DIGIKEY#" => "PCD1900CT-ND",  "MOUSER#" => "667-ELJ-RF1N5ZFB"},
            "1.8nH"    => {MANF => "Panasonic", "MANF#" => "ELJ-RF1N8ZFB", "DIGIKEY#" => "PCD1901CT-ND",  "MOUSER#" => "667-ELJ-RF1N8ZFB"},
            "2.7nH"    => {MANF => "Panasonic", "MANF#" => "ELJ-RF2N7ZFB", "DIGIKEY#" => "PCD1903CT-ND",  "MOUSER#" => "667-ELJ-RF2N7ZFB"},
            "3.1nH"    => {MANF => "Abracon",   "MANF#" => "ATFC-0402-3N1-BT", "DIGIKEY#" => "535-10372-1-ND",  "MOUSER#" => ""},
            "3.9nH"    => {MANF => "Panasonic", "MANF#" => "ELJ-RF3N9ZFB", "DIGIKEY#" => "PCD1905CT-ND",  "MOUSER#" => "667-ELJ-RF3N9ZFB"},
            "4.7nH"    => {MANF => "Panasonic", "MANF#" => "ELJ-RF4N7ZFB", "DIGIKEY#" => "PCD1906CT-ND",  "MOUSER#" => "667-ELJ-RF4N7ZFB"},
            "8.2nH"    => {MANF => "Panasonic", "MANF#" => "ELJ-RF8N2ZFB", "DIGIKEY#" => "PCD1909CT-ND",  "MOUSER#" => "667-ELJ-RF8N2ZFB"},
            "22nH"     => {MANF => "Panasonic", "MANF#" => "ELJ-RF22NGFB", "DIGIKEY#" => "PCD1914CT-ND",  "MOUSER#" => "667-ELJ-RF22NGFB"},
        },
    },
    "LD1117" => {
        "SOT223" => {
            # {MANF => "", "MANF#" => "", "DIGIKEY#" => "",  "MOUSER#" => ""},
            "3.3V" => {MANF => "STMicroelectronics", "MANF#" => "LD1117S33CTR", "DIGIKEY#" => "497-1241-1-ND",  "MOUSER#" => "511-LD1117S33C"},
        },
    },
    "CRYSTAL" => {
        ".3.2X2.5MM" => {
            "16MHz" => {MANF => "EPSON", "MANF#" => "TSX-3225 16.0000MF09Z-AC3", "DIGIKEY#" => "SER3628CT-ND",  "MOUSER#" => ""},
            "26MHz" => {MANF => "ABRACON", "MANF#" => "ABM8G-26.000MHZ-4Y-T3", "DIGIKEY#" => "535-10916-1-ND",  "MOUSER#" => ""},
        },
        ".5X3.2MM" => {
            #"12MHz" => {MANF => "TXC", "MANF#" => "7B-12.000MEEQ-T", "DIGIKEY#" => "887-1292-1-ND",  "MOUSER#" => ""},
            "12MHz" => {MANF => "CTS", "MANF#" => "405C11A12M00000", "DIGIKEY#" => "CTX833CT-ND",  "MOUSER#" => ""},
        },
    },
    "LSM115J"  => {MANF => "Microsemi", "MANF#" => "LSM115JE3/TR13", "DIGIKEY#" => "LSM115JE3/TR13CT-ND",  "MOUSER#" => ""},
    "A7105"    => {MANF => "Amiccom", "MANF#" => "", "DIGIKEY#" => "",  "MOUSER#" => ""},
    "CC2500"   => {MANF => "TI", "MANF#" => "CC2500RTKR", "DIGIKEY#" => "296-19586-2-ND",  "MOUSER#" => ""},
    "CYRF6936" => {MANF => "Cypress", "MANF#" => "CYRF6936-40LTXC", "DIGIKEY#" => "428-2962-ND",  "MOUSER#" => ""},
    "NRF24L01" => {MANF => "Nordic", "MANF#" => "NRF24L01P-R7", "DIGIKEY#" => "1490-1033-1-ND",  "MOUSER#" => ""},
    "RFX2401C" => {MANF => "RF Axis", "MANF#" => "RFX2401C", "DIGIKEY#" => "",  "MOUSER#" => ""},
    "SKY13384-350LF" => {MANF => "Skyworks", "MANF#" => "SKY13384-350LF", "DIGIKEY#" => "863-1456-1-ND",  "MOUSER#" => ""},
    "STM32-M-48" => {
        "" => {
            "STM32F072CB" => {MANF => "STMicroelectronics", "MANF#" => "STM32F072CBT6", "DIGIKEY#" => "497-14645-ND",  "MOUSER#" => ""},
        },
    },
    "U.FL" =>  {
        "" => {
            "U.FL" => {MANF => "Molex", "MANF#" => "0734120110", "DIGIKEY#" => "WM5587CT-ND",  "MOUSER#" => ""},
        },
    },
    "2X5" => {MANF => "Harwin", "MANF#" => "M22-2520505", "DIGIKEY#" => "952-1320-ND", "MOUSER#" => ""},
    "PINHD-1X05" => {
        "_2.54-S" => { MANF => "Sullins", "MANF#" => "PPPC051LFBN-RC", "DIGIKEY#" => "S7038-ND", "MOUSER#" => ""},
    },
    "USB" => {
        "SMD" => {MANF => "JAE", "MANF#" => "DX2R005HN2E700", "DIGIKEY#" => "670-1190-1-ND",  "MOUSER#" => ""},
    },
);
my $design = shift(@ARGV);
$design =~ s/\....$//;
my %map;
open my $fh, "<", "$design.sch" or die "Couldn't read $design.sch\n";
open my $outFH, ">", "$design.sch.new" or die "Couldn't write $design.sch\n";
while(<$fh>) {
    my $ref;
    my $line = $_;
    if (/<part.*deviceset="(\S+)" device="(\S*)" value="(\S+)"/ && $id{$1}{$2}{$3}) {
        $ref = $id{$1}{$2}{$3};
    } elsif(!/value=/ && /<part.*deviceset="(\S+)" device="(\S+)"/){
        $ref = $id{$1}{$2};
    } elsif(!/value=/ && /<part.*deviceset="(\S+)" device=""/){
        $ref = $id{$1};
    }
    if($ref) {
        if($line =~ /\/>/) {
            $line =~ s/\/>/>/;
        } else {
            while(<$fh>) {
                if(/attribute name="(\S+)"/ && grep {$1 eq $_} @attributes) {
                    next;
                } if(/<\/part>/) {
                    last;
                }
                $line .= $_;
            }
        }
        my($name) = ($line =~ /name=\"(\S+)\"/);
        $map{$name} = $ref;
        foreach my $key (sort keys %$ref) {
            $line .= "<attribute name=\"$key\" value=\"$ref->{$key}\"/>\n";
        }
        $line .= "</part>\n";
    } elsif(/attribute name="(\S+)"/ && grep {$1 eq $_} @attributes) {
        next;
    }
    print $outFH $line;
}
close $outFH;

open my $fh, "<", "$design.brd" or die "Couldn't read $design.brd\n";
open my $outFH, ">", "$design.brd.new" or die "Couldn't write $design.brd\n";
while(<$fh>) {
    my $line = $_;
    if(/<element\s.*name=\"(\S+)\"/ && $map{$1}) {
        my $ref = $map{$1};
        if($line =~ /\/>/) {
            $line =~ s/\/>/>/;
        } else {
            while(<$fh>) {
                if(/attribute name="(\S+)"/ && grep {$1 eq $_} @attributes) {
                    next;
                } if(/<\/element>/) {
                    last;
                }
                $line .= $_;
            }
        }
        foreach my $key (sort keys %$ref) {
            $line .= "<attribute name=\"$key\" value=\"$ref->{$key}\" size=\"1.778\" layer=\"27\" display=\"off\"/>\n";
        }
        $line .= "</element>\n";
    } elsif(/attribute name="(\S+)"/ && grep {$1 eq $_} @attributes) {
        next;
    }
    print $outFH $line;
}
close $outFH;
